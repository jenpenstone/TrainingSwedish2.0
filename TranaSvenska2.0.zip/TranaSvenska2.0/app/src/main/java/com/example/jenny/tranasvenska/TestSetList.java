package com.example.jenny.tranasvenska;

import java.util.ArrayList;

/**
 * Klass som skapar en lista med TestSet-objekt
 */
public class TestSetList {


    //lista med alla set med bild + texter.
    private ArrayList<TestSet> testSetlist;


    //lista över vilka nummer på bilder som ska visas.
    private ArrayList<Integer> imageNbrsList;

    //Konstruktor. Obs, tänk på att maxNbr är det högsta talet som får genereras.
    public TestSetList(int size, int maxNbr){
        testSetlist = new ArrayList<TestSet>();

        RandomNumbers rn = new RandomNumbers(size, maxNbr);
        //skapar lista för ordningsföljden av bilderna.
        imageNbrsList = rn.getNumbers();

        //tar fram vilka ord som ska visas för varje bild och slumpar fram hur de ska visas.
        for(int i = 0; i<imageNbrsList.size(); i++){
            int pictureNbr = imageNbrsList.get(i);
            ArrayList<Integer> threeNbrs = rn.getThreeNumbers(pictureNbr);
            int placeNbr = rn.getPlaceNbr();
            int[] words = new int[4];

            //slumpar ordningsföljden på orden.
            switch (placeNbr){
                case 0:
                    words[0] = pictureNbr;
                    words[1] = threeNbrs.get(0);
                    words[2] = threeNbrs.get(1);
                    words[3] = threeNbrs.get(2);
                    break;

                case 1:
                    words[0] = threeNbrs.get(0);
                    words[1] = pictureNbr;
                    words[2] = threeNbrs.get(1);
                    words[3] = threeNbrs.get(2);
                    break;

                case 2:
                    words[0] = threeNbrs.get(0);
                    words[1] = threeNbrs.get(1);
                    words[2] = pictureNbr;
                    words[3] = threeNbrs.get(2);
                    break;

                case 3:
                    words[0] = threeNbrs.get(0);
                    words[1] = threeNbrs.get(1);
                    words[2] = threeNbrs.get(2);
                    words[3] = pictureNbr;
                    break;

                default: break;
            }
            TestSet ts = new TestSet(pictureNbr, words);
            testSetlist.add(ts);

        }


    }

    public ArrayList<TestSet> getTestSetList(){
        return testSetlist;
    }



}
