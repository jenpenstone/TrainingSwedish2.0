package com.example.jenny.tranasvenska;

/**
 * Klass som skapar objekt med referenser till en bild och en lista med ord.
 */
public class TestSet {

    private int picture;
    private int[] words;

    public TestSet(int picture, int[] words){
        this.picture = picture;
        this.words = words;
    }

    public int getPicture(){
        return picture;
    }

    public int[] getWords(){
        return words;
    }
}
