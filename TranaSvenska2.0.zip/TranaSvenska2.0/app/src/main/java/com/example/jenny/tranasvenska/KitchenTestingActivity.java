package com.example.jenny.tranasvenska;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

public class KitchenTestingActivity extends AppCompatActivity {
    private int[] image_resources = {R.mipmap.avokado, R.mipmap.citron, R.mipmap.gaffel,
            R.mipmap.glas, R.mipmap.gryta, R.mipmap.kniv,
            R.mipmap.mugg, R.mipmap.ost, R.mipmap.paron,
            R.mipmap.potatis, R.mipmap.sked, R.mipmap.skal,
            R.mipmap.sotpotatis, R.mipmap.tallrik, R.mipmap.tomat,
            R.mipmap.zucchini};

    //Lista med text till bilder nivå 1
    private int[] imageName_resources_level1 = {R.string.avokado, R.string.citron, R.string.gaffel,
            R.string.glas, R.string.gryta, R.string.kniv,
            R.string.mugg, R.string.ost, R.string.paron,
            R.string.potatis, R.string.sked, R.string.skal,
            R.string.sotpotatis, R.string.tallrik, R.string.tomat,
            R.string.zucchini};

    private int[] imageName_resources_level2 = {R.string.en, R.string.ett};


    //lista för textresurserna
    private int[] imageName_resources;

    //variabel som håller reda på svårighetsnivån.
    private int testingLevel;

    //Antal bilder som ska ingå i testet.
    private int nbrPictures = 10;

    //TestSetList för att hantera och hålla reda på vilken bild och vilka ord som ska visas.
    private ArrayList<TestSet> pictureOrder;

    //variabler för utvald bild samt extra ord.
    private int imagePlace;
    private int[] buttonWords;

    //variabel som håller reda på vilken vy i testet som ska visas.
    private int viewNbr;

    //variabel som håller reda på resultatet
    private int correctAnswers;

    private ImageView imageView;
    private Button button1;
    private Button button2;
    private Button button3;
    private Button button4;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kitchen_testing);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //ställer in svårighetsgrad
        Intent intent = getIntent();
        this.testingLevel = intent.getIntExtra("KITCHEN_TESTING_LEVEL", 1);

        //skapar TestSetList
        TestSetList tsl = new TestSetList(nbrPictures, image_resources.length);
        pictureOrder = tsl.getTestSetList();

        //ställer in att testet är på startbilden och nollställer resultatvariabler.
        viewNbr = 0;
        correctAnswers = 0;


        //lagrar länk till bildvy
        imageView = (ImageView) findViewById(R.id.kitchen_test_image);

        //lagrar länkar till svarsknapparna
        button1 = (Button) findViewById(R.id.kitchen_test_button1);
        button2 = (Button) findViewById(R.id.kitchen_test_button2);
        button3 = (Button) findViewById(R.id.kitchen_test_button3);
        button4 = (Button) findViewById(R.id.kitchen_test_button4);

        setImageName_resources();
        setTestView();

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        //Ställer in vilka ikoner som ska visas i actionbar

        menu.findItem(R.id.action_home).setVisible(true);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        switch (id) {
            //hemknappen intryckt. Skickar tillbaka användaren till startsidan
            case R.id.action_home:
                Intent mainIntent = new Intent(this, MainActivity.class);
                startActivity(mainIntent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    /* Aktivitetshanterare för testknapparna.*/
    public void testButton1_pushed(View view) {
        manageButtonPushed(button1, 0);
    }

    public void testButton2_pushed(View view) {
        manageButtonPushed(button2, 1);
    }

    public void testButton3_pushed(View view) {
        manageButtonPushed(button3, 2);
    }

    public void testButton4_pushed(View view) {
        manageButtonPushed(button4, 3);
    }

    //metod som hanterar knapptryck.
    private void manageButtonPushed(Button button, int buttonWordNbr){
        final Button but = button;

        //kontrollerar om svaret är korrekt
        boolean rightAnswer = checkAnswer(buttonWords[buttonWordNbr]);
        //byter färg på intryckt knapp
        paintPushedButton(button, rightAnswer);

        button.postDelayed(new Runnable() {
            @Override
            public void run() {
                //återställer färgen på knappen
                resetColorOnButton(but);
                setTestView();
            }
        }, 500);

    }



    //metod som kontrollerar om svaret är rätt och lagrar resultatet.
    private boolean checkAnswer(int answerWord){
        if(imagePlace - answerWord == 0){
            correctAnswers++;
            return true;
        }
        return false;
    }

    //metod för att ställa in färg för intryckt knapp
    private void paintPushedButton(Button button, boolean answer){
        if(answer){
            button.setBackgroundColor(ContextCompat.getColor(getApplicationContext(), R.color.correctColor));
        }else{
            button.setBackgroundColor(ContextCompat.getColor(getApplicationContext(), R.color.incorrectColor));
        }

    }

    //metod för att återställa knappens färg
    private void resetColorOnButton(Button button){
        button.setBackgroundColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary));
    }

    //metod som ställer in vilken textresurs samt vilka knappar som ska användas/visas beroende på nivå.
    // Om nivå av någon anledning inte är vald så väljs nivå 1.
    private void setImageName_resources() {
        if (testingLevel == 3) {
            //Är under utveckling och är därför inte implementerad
            //imageName_resources = imageName_resources_level3;
        } else if (testingLevel == 2) {
            //Är under utveckling och är därför inte implementerad
            imageName_resources = imageName_resources_level2;

            button1.setVisibility(View.VISIBLE);
            button2.setVisibility(View.VISIBLE);
            button3.setVisibility(View.INVISIBLE);
            button4.setVisibility(View.INVISIBLE);
        } else {
            imageName_resources = imageName_resources_level1;

            button1.setVisibility(View.VISIBLE);
            button2.setVisibility(View.VISIBLE);
            button3.setVisibility(View.VISIBLE);
            button4.setVisibility(View.VISIBLE);
        }

    }

    //Metod som ställer in vyn för knapparna och bilden i testet. Om alla bilder visats kallar metoden på resultatmetoden.
    private void setTestView() {
        if(viewNbr == nbrPictures){
            viewNbr = 0;
            startKitchenTestingResult();
        }else{
            //hämta vilken bild och text som ska visas
            imagePlace = pictureOrder.get(viewNbr).getPicture();
            buttonWords = pictureOrder.get(viewNbr).getWords();
            imageView.setImageResource(image_resources[imagePlace]);

            if (testingLevel == 3) {
                //Är under utveckling och är därför inte implementerad
            } else if (testingLevel == 2) {
                //Är under utveckling och är därför inte implementerad
            } else {
                button1.setText(imageName_resources[buttonWords[0]]);
                button2.setText(imageName_resources[buttonWords[1]]);
                button3.setText(imageName_resources[buttonWords[2]]);
                button4.setText(imageName_resources[buttonWords[3]]);
            }
            //ökar variabeln för vilken bild i listan som ska visas med 1.
            viewNbr++;
        }

    }
    //Metod för att starta kökstests resultat
    private void startKitchenTestingResult() {
        int score = correctAnswers;
        correctAnswers = 0;
        Intent kitchenTestingResultIntent = new Intent(this, KitchenTestingResultsActivity.class);
        kitchenTestingResultIntent.putExtra("KITCHEN_TEST_RESULTS", score);
        kitchenTestingResultIntent.putExtra("KITCHEN_TEST_TOTAL", nbrPictures);
        startActivity(kitchenTestingResultIntent);
    }


}
