package com.example.jenny.tranasvenska;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

public class KitchenTrainingActivity extends AppCompatActivity {
    ViewPager viewPager;
    KitchenTrainingSwipeAdapter adapter;
    private int level;
    private MediaPlayer[] soundPlayer = new MediaPlayer[16];
    private int[] imageSound_resources;

    private int[] imageSound_resources_level1 = {R.raw.avokado1, R.raw.citron1, R.raw.gaffel1, R.raw.glas1,
            R.raw.gryta1, R.raw.kniv1, R.raw.mugg1, R.raw.ost1, R.raw.paron1,
            R.raw.potatis1, R.raw.sked1, R.raw.skal1, R.raw.sotpotatis1,
            R.raw.tallrik1, R.raw.tomat1, R.raw.zucchini1};

    private int[] imageSound_resources_level2 = {R.raw.avokado2, R.raw.citron2, R.raw.gaffel2, R.raw.glas2,
            R.raw.gryta2, R.raw.kniv2, R.raw.mugg2, R.raw.ost2, R.raw.paron2,
            R.raw.potatis2, R.raw.sked2, R.raw.skal2, R.raw.sotpotatis2,
            R.raw.tallrik2, R.raw.tomat2, R.raw.zucchini2};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kitchen_training);

        Intent intent = getIntent();
        level = intent.getIntExtra("KITCHEN_TRAINING_LEVEL", 1);

        //Skapar actionbar
        Toolbar toolbar = (Toolbar) findViewById(R.id.kitchenTraining_toolbar);
        setSupportActionBar(toolbar);

        //visa tillbakaknapp i Actionbar
        android.support.v7.app.ActionBar ab = getSupportActionBar();
        ab.setDisplayHomeAsUpEnabled(true);

        //skapar och ställer in swipefunktionen med text och bild
        viewPager = (ViewPager) findViewById(R.id.kitchenViewpager);
        adapter = new KitchenTrainingSwipeAdapter(this);
        adapter.setTrainingLevel(level);
        viewPager.setAdapter(adapter);

        //skapar ljudresurser
        setimageSound_resources();


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        //Ställer in vilka ikoner som ska visas i actionbar
        menu.findItem(R.id.action_home).setVisible(true);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        switch (id) {
            //hemknappen intryckt. Skickar tillbaka användaren till startsidan
            case R.id.action_home:
                Intent mainIntent = new Intent(this, MainActivity.class);
                startActivity(mainIntent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    //metod som ställer in vilken ljudresurs som ska användas beroende på nivå. Om nivå av någon anledning inte är vald så väljs nivå 1.
    private void setimageSound_resources(){
        if(level == 3){
            //Är under utveckling och är därför inte implementerad
            //imageSound_resources = imageSound_resources_level3;
        }else if(level == 2){
            imageSound_resources = imageSound_resources_level2;
        }else{
            imageSound_resources = imageSound_resources_level1;
        }
        for(int i = 0; i < soundPlayer.length; i++){
            soundPlayer[i] = MediaPlayer.create(this, imageSound_resources[i]);
        }
    }

    public void soundButton_pushed(View view) {
        int position = viewPager.getCurrentItem();
        soundPlayer[position].start();
    }

}
