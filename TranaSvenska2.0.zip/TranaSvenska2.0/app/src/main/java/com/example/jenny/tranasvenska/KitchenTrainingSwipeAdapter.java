package com.example.jenny.tranasvenska;

import android.content.Context;
import android.media.MediaPlayer;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Created by Jenny on 04/04/16.
 */
public class KitchenTrainingSwipeAdapter extends PagerAdapter {
    private int[] image_resources = {R.mipmap.avokado, R.mipmap.citron, R.mipmap.gaffel,
            R.mipmap.glas, R.mipmap.gryta, R.mipmap.kniv,
            R.mipmap.mugg, R.mipmap.ost, R.mipmap.paron,
            R.mipmap.potatis, R.mipmap.sked, R.mipmap.skal,
            R.mipmap.sotpotatis, R.mipmap.tallrik, R.mipmap.tomat,
            R.mipmap.zucchini};
    private int[] imageName_resources_level1 = {R.string.avokado,R.string.citron, R.string.gaffel,
            R.string.glas, R.string.gryta, R.string.kniv,
            R.string.mugg, R.string.ost, R.string.paron,
            R.string.potatis, R.string.sked, R.string.skal,
            R.string.sotpotatis, R.string.tallrik, R.string.tomat,
            R.string.zucchini};

    //Lista med text till bilder nivå 2
    private int[] imageName_resources_level2 = {R.string.avokado2,R.string.citron2, R.string.gaffel2,
            R.string.glas2, R.string.gryta2, R.string.kniv2,
            R.string.mugg2, R.string.ost2, R.string.paron2,
            R.string.potatis2, R.string.sked2, R.string.skal2,
            R.string.sotpotatis2, R.string.tallrik2, R.string.tomat2,
            R.string.zucchini2};


    private Context ctx;
    private LayoutInflater layoutInflater;
    private int[] imageName_resources;
    private int trainingLevel;

    public KitchenTrainingSwipeAdapter(Context ctx){
        this.ctx = ctx;
    }

    @Override
    public int getCount() {
        return image_resources.length;
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {

        //Sets connection to the layout for the swipe.
        layoutInflater = (LayoutInflater) ctx.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View item_view = layoutInflater.inflate(R.layout.kitchen_training_swipe_layout, container, false);

        //Sets connection to the resources for images and image-names.
        ImageView imageView = (ImageView) item_view.findViewById(R.id.kitchen_training_swipe_image);
        TextView textView = (TextView) item_view.findViewById(R.id.kitchen_training_swipe_imageName);


        //Puts the right image and names in the layout
        imageView.setImageResource(image_resources[position]);
        textView.setText(imageName_resources[position]);
        container.addView(item_view);




        return item_view;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((LinearLayout) object);
    }


   public void setTrainingLevel(int level){
       trainingLevel = level;
       setimageName_resources();
   }

    //metod som ställer in vilken textresurs som ska användas beroende på nivå. Om nivå av någon anledning inte är vald så väljs nivå 1.
    private void setimageName_resources(){
        if(trainingLevel == 3){
            //Är under utveckling och är därför inte implementerad
            //imageName_resources = imageName_resources_level3;
        }else if(trainingLevel == 2){
            imageName_resources = imageName_resources_level2;
        }else{
            imageName_resources = imageName_resources_level1;
        }

    }

}
