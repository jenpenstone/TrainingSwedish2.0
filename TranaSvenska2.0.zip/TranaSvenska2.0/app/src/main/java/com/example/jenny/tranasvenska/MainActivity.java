package com.example.jenny.tranasvenska;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.main_toolbar);
        setSupportActionBar(toolbar);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        menu.findItem(R.id.action_info).setVisible(true);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        switch (id){
            case R.id.action_info:
                Intent infoIntent = new Intent(this, InformationActivity.class);
                startActivity(infoIntent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }

    }




    /* Aktivitetshanterare för köksknappen. Öppnar tema-aktiviteten kök */
    public void kitchenButton_pushed(View view) {
        goToKitchen(view);
    }

    //Metod för att gå till biblioteket
    private void goToKitchen(View view) {
        Intent kitchenIntent = new Intent(this, KitchenActivity.class);
        startActivity(kitchenIntent);
    }

    /* Aktivitetshanterare för idrottshall-knappen. Öppnar tema-aktiviteten idrottshall */
    public void gymnasticshallButton_pushed(View view) {
        //meddelar att det inte är implementerat än
        Toast.makeText(this, "Idrottshallen: " + getString(R.string.not_implemented), Toast.LENGTH_SHORT).show();
    }

    /* Aktivitetshanterare för skolgårdsknappen. Öppnar tema-aktiviteten skolgård */
    public void schoolyardButton_pushed(View view) {
        //meddelar att det inte är implementerat än
        Toast.makeText(this, "Skolgården: " + getString(R.string.not_implemented), Toast.LENGTH_SHORT).show();
    }

    /* Aktivitetshanterare för badrums-knappen. Öppnar tema-aktiviteten badrum */
    public void bathroomButton_pushed(View view) {
        //meddelar att det inte är implementerat än
        Toast.makeText(this, "Badrummet: " + getString(R.string.not_implemented), Toast.LENGTH_SHORT).show();
    }

}
