package com.example.jenny.tranasvenska;

import java.util.ArrayList;
import java.util.Random;

/**
 * Klass som slumpar fram nummer för att de bilder med text som visas i testaktiviteterna inte ska ha samma ordning och rätt svar på samma plats varje gång.
 */
public class RandomNumbers {

    private ArrayList<Integer> numbers;
    private ArrayList<Integer> allNumbers;
    //hur många bilder som ska visas i testet
    private int size;
    //hur många bilder som finns i den ursprungliga listan(övningslistan).
    private int maxNbr;

    //konstruktor som ställer in alla inställningar och begränsningar för slumplistan.
    public RandomNumbers(int size, int maxNbr){
        this.size = size;
        this.maxNbr = maxNbr;
        numbers = new ArrayList<Integer>();
        setAllNumbers();

    }
    //metod som returnerar en lista med slumptal.
    public ArrayList<Integer> getNumbers(){
        for(int i = 0; i<size; i++){
            int newNbr = randomOneNumber();
            numbers.add(newNbr);
        }
        return numbers;
    }

    //metod som slumpar fram tre tal mellan 0 och maxNbr som inte redan är det valda numret och returnerar de i en lista.
    public ArrayList<Integer> getThreeNumbers(int place){
        ArrayList<Integer> numbers = new ArrayList<Integer>();
        Random rand = new Random();
        while(numbers.size() != 3){
            int tempNbr = rand.nextInt(maxNbr);
            if(tempNbr != place){
                boolean nbrIsTaken = false;
                for(int j = 0; j<numbers.size(); j++){
                    if(numbers.get(j) == tempNbr){
                        nbrIsTaken = true;
                    }
                }
                if(!nbrIsTaken){
                    numbers.add(tempNbr);
                }
            }
        }
        return numbers;
    }

    //metod som returnerar en placeringssiffra 0-3 för vilken placering rätt ord ska ha.
    public int getPlaceNbr(){
        Random rand = new Random();
        int nbr = rand.nextInt(4);
        return nbr;
    }

    //metod som slumpar ett nummer från nummerlistan, tar bort det ur listan, och returnerar talet.
    private int randomOneNumber(){
        Random rand = new Random();
        int place = rand.nextInt(allNumbers.size());
        int number = allNumbers.remove(place);
        return number;
    }

    //metod som skapar en lista med alla möjliga nummer upp till maxnumret.
    private void setAllNumbers(){
        allNumbers = new ArrayList<Integer>();
        for(int i = 0; i<maxNbr; i++){
            allNumbers.add(i);
        }
    }
}
